import Page from "../models/page.model.js";
import asyncHandler from "../utils/asyncHandler.js";
import ApiError from "../utils/ApiError.js";
import ApiResponse from "../utils/ApiResponse.js";

// @desc    Create a new page
export const createPage = asyncHandler(async (req, res) => {
  const { title, description, topicTags } = req.body;

  if (!title) throw new ApiError(400, "Title is required");

  const page = await Page.create({
    createdBy: req.user._id,
    title,
    description,
    topicTags,
  });

  return res
    .status(201)
    .json(new ApiResponse(201, page, "Page created successfully"));
});

// @desc    Get all pages for current user
export const getAllPages = asyncHandler(async (req, res) => {
  const pages = await Page.find({ createdBy: req.user._id }).sort("-createdAt");

  return res
    .status(200)
    .json(new ApiResponse(200, pages, "Pages fetched successfully"));
});

// @desc    Get single page by ID
export const getPageById = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const page = await Page.findOne({
    _id: id,
    createdBy: req.user._id,
  });

  if (!page) throw new ApiError(404, "Page not found");

  return res
    .status(200)
    .json(new ApiResponse(200, page, "Page fetched successfully"));
});

// @desc    Update page by ID
export const updatePage = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const updates = req.body;

  const page = await Page.findOneAndUpdate(
    { _id: id, createdBy: req.user._id },
    updates,
    { new: true }
  );

  if (!page) throw new ApiError(404, "Page not found or not authorized");

  return res
    .status(200)
    .json(new ApiResponse(200, page, "Page updated successfully"));
});

// @desc    Delete page by ID
export const deletePage = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const deleted = await Page.findOneAndDelete({
    _id: id,
    createdBy: req.user._id,
  });

  if (!deleted) throw new ApiError(404, "Page not found or not authorized");

  return res
    .status(200)
    .json(new ApiResponse(200, deleted, "Page deleted successfully"));
});
