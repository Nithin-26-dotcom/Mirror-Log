// createRoadmap,
//   getRoadmapById,
//   getRoadmapByPageId
//   updateRoadmap,
//   deleteRoadmap,
//   addSubheading,
//   addTodoToSubheading,
//   updateTodo,
//   deleteTodoFromSubheading,
import asyncHandler from "../utils/asyncHandler.js";
import ApiError from "../utils/ApiError.js";
import ApiResponse from "../utils/ApiResponse.js";
import Roadmap from "../models/roadmap.model.js";
import Todo from "../models/todo.model.js";
import Page from "../models/page.model.js";
import Todo from "../models/todo.model.js";

// Create a new roadmap
export const createRoadmap = asyncHandler(async (req, res) => {
  const { pageId, startDate, endDate, isRecurring, subheadings } = req.body;

  const roadmap = await Roadmap.create({
    pageId,
    startDate,
    endDate,
    isRecurring,
    subheadings,
  });

  return res
    .status(201)
    .json(new ApiResponse(201, roadmap, "Roadmap created successfully"));
});

// Get roadmap by ID
export const getRoadmapById = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const roadmap = await Roadmap.findById(id)
    .populate("pageId")
    .populate("subheadings.todos");

  if (!roadmap) throw new ApiError(404, "Roadmap not found");

  return res
    .status(200)
    .json(new ApiResponse(200, roadmap, "Roadmap fetched successfully"));
});

// Get roadmap by page ID
export const getRoadmapByPageId = asyncHandler(async (req, res) => {
  const { pageId } = req.params;

  const roadmap = await Roadmap.findOne({ pageId }).populate({
    path: "subheadings.todos",
  });

  if (!roadmap) {
    throw new ApiError(404, "No roadmap found for this page");
  }

  return res
    .status(200)
    .json(new ApiResponse(200, roadmap, "Roadmap fetched successfully"));
});

// Update roadmap
export const updateRoadmap = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const updateData = req.body;

  const updated = await Roadmap.findByIdAndUpdate(id, updateData, {
    new: true,
  }).populate("subheadings.todos");

  if (!updated) throw new ApiError(404, "Roadmap not found for update");

  return res
    .status(200)
    .json(new ApiResponse(200, updated, "Roadmap updated successfully"));
});

// Delete roadmap
export const deleteRoadmap = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const roadmap = await Roadmap.findById(id);
  if (!roadmap) throw new ApiError(404, "Roadmap not found");

  // Optionally delete all Todos
  const allTodos = roadmap.subheadings.flatMap((s) => s.todos);
  await Todo.deleteMany({ _id: { $in: allTodos } });

  await roadmap.deleteOne();

  return res
    .status(200)
    .json(new ApiResponse(200, {}, "Roadmap deleted successfully"));
});

// Add a subheading
export const addSubheading = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { title } = req.body;

  const roadmap = await Roadmap.findById(id);
  if (!roadmap) throw new ApiError(404, "Roadmap not found");

  roadmap.subheadings.push({ title, todos: [] });
  await roadmap.save();

  return res
    .status(200)
    .json(new ApiResponse(200, roadmap, "Subheading added successfully"));
});

// Add a todo to a subheading
export const addTodoToSubheading = asyncHandler(async (req, res) => {
  const { id, subheadingIndex } = req.params;
  const { content } = req.body;

  const roadmap = await Roadmap.findById(id);
  if (!roadmap || !roadmap.subheadings[subheadingIndex])
    throw new ApiError(404, "Subheading not found");

  const newTodo = await Todo.create({ content });
  roadmap.subheadings[subheadingIndex].todos.push(newTodo._id);
  await roadmap.save();

  return res
    .status(201)
    .json(
      new ApiResponse(
        201,
        { todo: newTodo },
        "Todo added to subheading successfully"
      )
    );
});

// Update a todo
export const updateTodo = asyncHandler(async (req, res) => {
  const { todoId } = req.params;
  const { content, isCompleted } = req.body;

  const updated = await Todo.findByIdAndUpdate(
    todoId,
    { content, isCompleted },
    { new: true }
  );

  if (!updated) throw new ApiError(404, "Todo not found");

  return res
    .status(200)
    .json(new ApiResponse(200, updated, "Todo updated successfully"));
});

// Delete a todo and remove from subheading
export const deleteTodoFromSubheading = asyncHandler(async (req, res) => {
  const { roadmapId, subheadingIndex, todoId } = req.params;

  const roadmap = await Roadmap.findById(roadmapId);
  if (!roadmap || !roadmap.subheadings[subheadingIndex])
    throw new ApiError(404, "Subheading not found");

  roadmap.subheadings[subheadingIndex].todos = roadmap.subheadings[
    subheadingIndex
  ].todos.filter((id) => id.toString() !== todoId);
  await roadmap.save();

  await Todo.findByIdAndDelete(todoId);

  return res
    .status(200)
    .json(new ApiResponse(200, {}, "Todo deleted successfully"));
});
