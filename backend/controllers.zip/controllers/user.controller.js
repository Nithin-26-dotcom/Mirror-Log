import { User } from "../models/user.model.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import { ApiError } from "../utils/ApiError.js";
import { asyncHandler } from "../utils/asyncHandler.js";

// @desc    Create a new user
// @route   POST /api/users
const createUser = asyncHandler(async (req, res) => {
  const { username, email, password, role } = req.body;

  if (!username || !email || !password) {
    throw new ApiError(400, "Username, email, and password are required");
  }

  const isExist = await User.findOne({ $or: [{ email }, { username }] });
  if (isExist) {
    throw new ApiError(409, "Username or email already in use");
  }
  if (!role) {
    req.body.role = "user";
  }

  const user = new User({ username, email, password, role });
  await user.save();

  res.status(201).json(new ApiResponse(201, user, "User created successfully"));
});

// @desc    Get a user by ID
// @route   GET /api/users/:id
const getUserById = asyncHandler(async (req, res) => {
  const { id } = req.params;

  // Only allow if user is admin or accessing own profile
  if (req.user.role !== "admin" && req.user.id.toString() !== id) {
    throw new ApiError(403, "Access denied");
  }

  const user = await User.findById(id).select("-password -refreshToken");
  if (!user) {
    throw new ApiError(404, "User not found");
  }

  res.status(200).json(new ApiResponse(200, user, "User fetched successfully"));
});

// @desc    Get all users
// @route   GET /api/users
const getAllUsers = asyncHandler(async (req, res) => {
  const users = await User.find().select("-password -refreshToken");
  res
    .status(200)
    .json(new ApiResponse(200, users, "All users fetched successfully"));
});

// @desc    Update a user partially
// @route   PATCH /api/users/:id
const updateUser = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const updateData = req.body;

  // Sanitize: prevent empty/invalid fields
  Object.keys(updateData).forEach((key) => {
    if (
      updateData[key] === "" ||
      updateData[key] === undefined ||
      updateData[key] === null
    ) {
      delete updateData[key];
    }
  });

  const updatedUser = await User.findByIdAndUpdate(id, updateData, {
    new: true,
    runValidators: true,
  }).select("-password -refreshToken");

  if (!updatedUser) {
    throw new ApiError(404, "User not found");
  }

  res
    .status(200)
    .json(new ApiResponse(200, updatedUser, "User updated successfully"));
});

// @desc    Replace a user (PUT)
// @route   PUT /api/users/:id
const replaceUser = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { username, email, password } = req.body;

  const user = await User.findById(id);
  if (!user) {
    throw new ApiError(404, "User not found");
  }

  user.username = username;
  user.email = email;
  user.password = password;

  const savedUser = await user.save();
  res
    .status(200)
    .json(new ApiResponse(200, savedUser, "User replaced successfully"));
});

// @desc    Delete a user
// @route   DELETE /api/users/:id
const deleteUser = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const deletedUser = await User.findByIdAndDelete(id);

  if (!deletedUser) {
    throw new ApiError(404, "User not found");
  }

  res
    .status(200)
    .json(new ApiResponse(200, deletedUser, "User deleted successfully"));
});

export {
  createUser,
  getUserById,
  getAllUsers,
  updateUser,
  replaceUser,
  deleteUser,
};
