import Log from "../models/log.model.js";
import Tag from "../models/tag.model.js";

// @desc    Create a new log entry
// @route   POST /api/logs
export const createLog = async (req, res) => {
  try {
    const { page, content, tag, topic } = req.body;
    const user = req.user._id;

    const newLog = await Log.create({
      user,
      page,
      content,
      tag,
      topic,
    });

    res.status(201).json(newLog);
  } catch (error) {
    console.error("Error creating log:", error);
    res.status(500).json({ message: "Failed to create log" });
  }
};

// @desc    Get all logs by user
// @route   GET /api/logs
export const getUserLogs = async (req, res) => {
  try {
    const logs = await Log.find({ user: req.user._id })
      .populate("tag", "name")
      .populate("page", "title")
      .sort({ createdAt: -1 });

    res.status(200).json(logs);
  } catch (error) {
    console.error("Error fetching logs:", error);
    res.status(500).json({ message: "Failed to fetch logs" });
  }
};

// @desc    Update a specific log
// @route   PUT /api/logs/:id
export const updateLog = async (req, res) => {
  try {
    const { content, tag, topic } = req.body;
    const logId = req.params.id;

    const updatedLog = await Log.findOneAndUpdate(
      { _id: logId, user: req.user._id },
      { content, tag, topic },
      { new: true }
    );

    if (!updatedLog) {
      return res.status(404).json({ message: "Log not found" });
    }

    res.status(200).json(updatedLog);
  } catch (error) {
    console.error("Error updating log:", error);
    res.status(500).json({ message: "Failed to update log" });
  }
};

// @desc    Delete a specific log
// @route   DELETE /api/logs/:id
export const deleteLog = async (req, res) => {
  try {
    const logId = req.params.id;

    const deleted = await Log.findOneAndDelete({
      _id: logId,
      user: req.user._id,
    });

    if (!deleted) {
      return res.status(404).json({ message: "Log not found" });
    }

    res.status(200).json({ message: "Log deleted successfully" });
  } catch (error) {
    console.error("Error deleting log:", error);
    res.status(500).json({ message: "Failed to delete log" });
  }
};
