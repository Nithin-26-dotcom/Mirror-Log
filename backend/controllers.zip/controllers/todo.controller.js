// ============ WE DON'T NEED TODO CONTROLLER ===========
// import Todo from "../models/todo.model.js";
// import asyncHandler from "../utils/asyncHandler.js";
// import ApiError from "../utils/ApiError.js";
// import ApiResponse from "../utils/ApiResponse.js";

// // @desc    Get all todos
// // @route   GET /api/todos
// // @access  Private (but not linked to user in DB)
// const getAllTodos = asyncHandler(async (req, res) => {
//   const todos = await Todo.find().sort({ createdAt: -1 });

//   return res
//     .status(200)
//     .json(new ApiResponse(200, todos, "Todos fetched successfully"));
// });

// // @desc    Create a new todo
// // @route   POST /api/todos
// // @access  Private
// const createTodo = asyncHandler(async (req, res) => {
//   const { content } = req.body;

//   if (!content) {
//     throw new ApiError(400, "Content is required");
//   }

//   const newTodo = await Todo.create({ content });

//   return res
//     .status(201)
//     .json(new ApiResponse(201, newTodo, "Todo created successfully"));
// });

// // @desc    Update a todo
// // @route   PUT /api/todos/:id
// // @access  Private
// const updateTodo = asyncHandler(async (req, res) => {
//   const { content, isCompleted } = req.body;

//   const todo = await Todo.findById(req.params.id);

//   if (!todo) {
//     throw new ApiError(404, "Todo not found");
//   }

//   if (content !== undefined) todo.content = content;
//   if (isCompleted !== undefined) todo.isCompleted = isCompleted;

//   await todo.save();

//   return res
//     .status(200)
//     .json(new ApiResponse(200, todo, "Todo updated successfully"));
// });

// // @desc    Delete a todo
// // @route   DELETE /api/todos/:id
// // @access  Private
// const deleteTodo = asyncHandler(async (req, res) => {
//   const todo = await Todo.findByIdAndDelete(req.params.id);

//   if (!todo) {
//     throw new ApiError(404, "Todo not found");
//   }

//   return res
//     .status(200)
//     .json(new ApiResponse(200, null, "Todo deleted successfully"));
// });

// export { getAllTodos, createTodo, updateTodo, deleteTodo };
