import Tag from "../models/tag.model.js";
import asyncHandler from "../utils/asyncHandler.js";
import ApiResponse from "../utils/ApiResponse.js";
import ApiError from "../utils/ApiError.js";

// @desc    Get all tags
// @route   GET /api/tags
// @access  Private
const getAllTags = asyncHandler(async (req, res) => {
  const tags = await Tag.find().sort({ createdAt: -1 });
  return res
    .status(200)
    .json(new ApiResponse(200, tags, "Tags fetched successfully"));
});

// @desc    Create a new tag
// @route   POST /api/tags
// @access  Private
const createTag = asyncHandler(async (req, res) => {
  const { name, type } = req.body;

  if (!name) throw new ApiError(400, "Tag name is required");

  const existing = await Tag.findOne({ name });
  if (existing) throw new ApiError(409, "Tag already exists");

  const tag = await Tag.create({ name, type });

  return res
    .status(201)
    .json(new ApiResponse(201, tag, "Tag created successfully"));
});

// @desc    Update a tag
// @route   PUT /api/tags/:id
// @access  Private
const updateTag = asyncHandler(async (req, res) => {
  const { name, type } = req.body;

  const tag = await Tag.findById(req.params.id);
  if (!tag) throw new ApiError(404, "Tag not found");

  if (name) tag.name = name;
  if (type) tag.type = type;

  await tag.save();

  return res
    .status(200)
    .json(new ApiResponse(200, tag, "Tag updated successfully"));
});

// @desc    Delete a tag
// @route   DELETE /api/tags/:id
// @access  Private
const deleteTag = asyncHandler(async (req, res) => {
  const tag = await Tag.findByIdAndDelete(req.params.id);

  if (!tag) throw new ApiError(404, "Tag not found");

  return res
    .status(200)
    .json(new ApiResponse(200, null, "Tag deleted successfully"));
});

export { getAllTags, createTag, updateTag, deleteTag };
